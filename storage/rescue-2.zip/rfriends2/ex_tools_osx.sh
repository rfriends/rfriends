#!/bin/sh
# -----------------------------------------
# Rfriends (radiko radiru録音ツール)
# 2020/03/30
# 2021/02/26
# 2022/02/04
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends2
bit=`getconf LONG_BIT`

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi

cat $ver
echo ベースディレクトリは　$base です
echo OSは $bit bitsバージョンです
echo 
echo これは OSX 用です
# -----------------------------------------
# ツールのインストール
# -----------------------------------------
brew update
# -----------------------------------------
#  php, ffmpeg, at, gpac, swftools,mp4v2-utils
# -----------------------------------------
echo
echo rfriends Setup Utility Ver. 2.01
echo
echo
echo php, ffmpeg, mp4v2, wget
echo
echo "上記ツールをインストールしますか　(y/n) ?"
read ans
if [ $ans = "y" ]; then
	brew install php@7.4
	brew link php@7.4
	#brew link php@7.4 --force

	brew install ffmpeg

	brew install wget
	brew install mp4v2
	brew install atomicparsley
        brew install pidof

	#brew install at
	#brew install gpac
	#brew install swftools
	#brew install imagemagick
	#brew install mp4v2-utils
	#brew install curl
	#brew install unzip
fi
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
# -----------------------------------------
