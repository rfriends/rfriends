#!/bin/sh
# -----------------------------------------
# Rfriends (radiko radiru録音ツール)
# 2020/03/29
# 2021/02/26
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends2
bit=`getconf LONG_BIT`

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi

cat $ver
echo ベースディレクトリは　$base です
echo OSは $bit bitsバージョンです
echo
echo "これは CentOS7 用です"
echo
echo epel, Remi, Nux
echo "上記リポジトリを追加しますか　(y/n) ?"
read ans
if [ "$ans" = "y" ]; then
	# epel
	sudo yum install epel-release

	# Remiリポジトリ(PHP)
	sudo rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
	sudo yum -y install yum-utils
	sudo yum-config-manager --enable remi-php73

	# Nux リポジトリ for Centos 7
	sudo rpm -v --import http://li.nux.ro/download/nux/RPM-GPG-KEY-nux.ro
	sudo rpm -Uvh http://li.nux.ro/download/nux/dextop/el7/x86_64/nux-dextop-release-0-5.el7.nux.noarch.rpm

	sudo rpm -ihv http://awel.domblogger.net/7/media/x86_64/awel-media-release-7-6.noarch.rpm

fi
# -----------------------------------------
# ツールのインストール
# -----------------------------------------
echo
echo "yum update します"
echo
sudo yum update
# -----------------------------------------
#  php, ffmpeg, at, gpac, swftools,mp4v2-utils
# -----------------------------------------
echo
echo rfriends Setup Utility Ver. 2.00
echo
echo
echo php, ffmpeg, at, libmp4v2
echo

echo "上記ツールをインストールしますか　(y/n) ?"
read ans
if [ "$ans" = "y" ]; then

	sudo yum -y install php-cli
	sudo yum -y install php-xml
	sudo yum -y install php-zip
	sudo yum -y install php-mbstring

	sudo yum -y install ffmpeg

	sudo yum -y install at
	sudo yum -y install libmp4v2
	sudo yum -y install atomicparsley

	#sudo yum -y install gpac
	#sudo yum -y install ImageMagick
	#sudo yum -y install swftools
	#sudo yum -y install curl
	#sudo yum -y install unzip

fi
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
# -----------------------------------------
