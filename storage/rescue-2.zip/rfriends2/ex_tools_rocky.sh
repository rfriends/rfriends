#!/bin/sh
# -----------------------------------------
# Rfriends (radiko radiru録音ツール)
# 2022/03/18
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends2
bit=`getconf LONG_BIT`

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi

cat $ver
echo ベースディレクトリは　$base です
echo OSは $bit bitsバージョンです
echo
echo "これは Rocky Linux 8 用です"
echo
echo "リポジトリを追加しますか　(y/n) ?"
read ans
if [ "$ans" = "y" ]; then
    sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm
    sudo yum install https://download1.rpmfusion.org/free/el/rpmfusion-free-release-8.noarch.rpm https://download1.rpmfusion.org/nonfree/el/rpmfusion-nonfree-release-8.noarch.rpm
    sudo yum install http://rpmfind.net/linux/epel/7/x86_64/Packages/s/SDL2-2.0.14-2.el7.x86_64.rpm
fi
# -----------------------------------------
# ツールのインストール
# -----------------------------------------
echo
echo "yum update します"
echo
sudo yum update
# -----------------------------------------
#  php, ffmpeg, at, gpac, swftools,mp4v2-utils,atomicparsley
# -----------------------------------------
echo
echo rfriends Setup Utility Ver. 2.00
echo
echo
echo php, ffmpeg, at, AtomicParsley
echo

echo "上記ツールをインストールしますか　(y/n) ?"
read ans
if [ "$ans" = "y" ]; then

	sudo yum -y install php-cli
	sudo yum -y install php-xml
	sudo yum -y install php-zip
	sudo yum -y install php-mbstring
	sudo yum -y install php-json

	sudo yum -y install ffmpeg ffmpeg-devel
	sudo yum -y install at
	sudo yum -y install AtomicParsley

	#sudo yum -y install libmp4v2
	#sudo yum -y install gpac
	#sudo yum -y install ImageMagick
	#sudo yum -y install swftools
	#sudo yum -y install curl
	#sudo yum -y install unzip

fi
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
# -----------------------------------------
