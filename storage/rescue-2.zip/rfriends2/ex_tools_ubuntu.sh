#!/bin/sh
# -----------------------------------------
# Rfriends (radiko radiru録音ツール)
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends2
bit=`getconf LONG_BIT`

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi

cat $ver
echo ベースディレクトリは　$base です
echo OSは $bit bitsバージョンです

# -----------------------------------------
# ツールのインストール
# 2022/06/30
# -----------------------------------------
echo
echo rfriends Setup Utility Ver. 2.20
echo
# -----------------------------------------
ar=`dpkg --print-architecture`
bit=`getconf LONG_BIT`
echo
echo アーキテクチュアは、$ar $bit bits です。
# -----------------------------------------
echo
echo ツールをインストール
echo
sudo apt -y install unzip
sudo apt -y install at
sudo apt -y install nano
sudo apt -y install vim

sudo apt -y install php-cli
sudo apt -y install php-xml
sudo apt -y install php-zip
sudo apt -y install php-mbstring

sudo apt -y install mp4v2-utils
sudo apt -y install atomicparsley

# -----------------------------------------
echo
echo ffmpegをインストール
echo

sudo apt -y install ffmpeg
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
# -----------------------------------------
