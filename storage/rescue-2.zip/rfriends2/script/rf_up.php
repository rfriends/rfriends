<?php
//------------------------------------------------------------
//
// rfriends
//
// 2021/04/13 by mapi
//
//------------------------------------------------------------
//require_once ("rf_inc.php");
//require_once("rf_gateway.php");
//require_once("rf_gateway_ext.php");
require_once("rf_upd_common.php");
require_once("rf_upd_system.php");
require_once("rf_up_inc.php");
$rfriends_mes = "ラジオ録音ツール";

rfmenu_update_sub($upty);
