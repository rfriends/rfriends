<?php
//  --------------------------------------------------------------------------
// ---------------------------------------------
// rfriends ver.
// ---------------------------------------------
// usr以下は消さない
//
function rf_factory_reset($testmode)
{
// 1:test 0:normal
global $base;
global $tmpdir;
global $ex_radiko;
global $ex_radiru;

echo_msg(2,"");
echo_msg(2,"・設定データをバックアップします。");
if ($testmode == 0) {
    $ret = rf_setting_backup();
    if ($ret === false) {
        echo_msg(2,"設定データのバックアップに失敗しました。");
        echo_msg(2, "done");
        return;
    }
}
//echo_msg(2,"この機能は現在停止中です。");
//return;

echo_msg(2,"");
echo_msg(2,"・デイリー処理自動化を解除します。");
if ($testmode == 0) {
    rfgw_reset_cron();
}

echo_msg(2,"");
echo_msg(2,"・ラジコの予約を削除します。");
if ($testmode == 0) {
    rfmenu_rec_dsp($ex_radiko,1);
}

echo_msg(2,"");
echo_msg(2,"・らじるの予約を削除します。");
if ($testmode == 0) {
    rfmenu_rec_dsp($ex_radiru,1);
}
echo_msg(2,"");
echo_msg(2,"・実行中の録音をキャンセルします。");
if ($testmode == 0) {
    $n = rfmenu_rec_abort_all();
    if ($n > 0) {
        echo_msg(2,"");
        echo_msg(2,"・3秒間待機します。");
        sleep(3);
    }
}

echo_msg(2,"");
echo_msg(2,"・各種一時データを削除します。");
$dirs = [
"tmp",
"rsv",
"rsv/sch",
"ext",
"etc",
"config",
];
/*
    echo_msg(2,"$tmpdir");
    if (is_dir($tmpdir)) {
        rf_remove_dir_files("$tmpdir");
    } else {
        //echo_msg(2, "not dir");
    }
*/
echo_msg(2,"");
foreach ($dirs as $dir) {
    $dirx = $base.$dir;
    echo_msg(2,"$dirx");
    if (is_dir($dirx)) {
        if ($testmode == 0) {
            rf_remove_dir_files("$dirx");
        }
    } else {
        //echo_msg(2, "not dir");
    }
}

}
//  --------------------------------------------------------------------------
function rf_setting_backup()
{
    global $cfgdir;
    global $tmpdir;
    global $kwbackupdir;

    global $setting_name_dat;

    $setting = array();
    foreach($setting_name_dat as $key => $setting_name) {
        $setting[] = $cfgdir.$key;
    }
    $st = time();
    $dt = date("Ymd_His",$st);
    $src = "cfg_auto_".$dt.".zip";
    $fl = $tmpdir.$src;
    $ret = rf_zip($setting,"cfg",$fl);
    if ($ret !== false) {
        $ret = rf_move($fl,$kwbackupdir.$src);
        echo_msg(2,$kwbackupdir.$src);
    }
    return $ret;
}
//------------------------------------------------------------
// ディレクトリ内のファイルのみ削除
//
function rf_remove_dir_files($dir)
{
if (!is_dir($dir)) return;

$files = array_diff(scandir($dir), array('.','..'));
foreach ($files as $file) {
    if (is_dir("$dir/$file")) {
        rf_remove_dir_files("$dir/$file");
    } else {
        unlink("$dir/$file");
        //echo_msg(2, "delete : ".$dir."/".$file);
    }
}
}
//------------------------------------------------------------
// ディレクトリ内のファイルを削除し、ディレクトリを削除
//
function rf_remove_dir($dir)
{
if (!is_dir($dir)) return;

$files = array_diff(scandir($dir), array('.','..'));
foreach ($files as $file) {
    if (is_dir("$dir/$file")) {
        rf_remove_dir("$dir/$file");
    } else {
        unlink("$dir/$file");
        //echo_msg(2, "delete : ".$dir."/".$file);
    }
}
rmdir($dir);
//echo_msg(2, "delete dir : $dir");
}
// ---------------------------------------------
function rf_get_ver($dr)
{
    global $rfriends;

    $rf_fl = $dr.$rfriends;
    if (!file_exists($rf_fl)) {
        retrun("");
    }
    $rf = file_get_contents($rf_fl);
    $ver = explode(" ", trim($rf));
    return ($ver[3]);
}
// ---------------------------------------------
// rfriends fin
// ---------------------------------------------
function rf_update_fin_sys()
{
    global $tmpdir;
    global $rfriends;
    global $rfproduct;

    $rf_fl = $rfriends;
    $up_fl = "update.zip";
    $tmpdir_rf = $tmpdir.$rfproduct;

    // for update mes
    //fin_unlink($tmpdir.$rf_fl);
    fin_unlink($tmpdir.$up_fl);
    rm_dir($tmpdir_rf);
    return;
}
//  --------------------------------------------------------------------------
function rf_update_script($url,$update_dat, $up_fl, $rpath, $pn,$ty)
{
    global $tmpdir;

    global $base;
    global $rfriends;
    global $rfproduct;
    global $DS;

    //rf_error_log('update start');

    $tmpdir_rf = $tmpdir.$rfproduct;
    // ------------------------
    // アップデートファイルのダウンロード
    // ------------------------
    //echo_msg(2, "ダウンロード(update).....");
    fin_unlink($tmpdir.$up_fl);

    $ret = rf_update_get_sys($url,$up_fl, $tmpdir, $ty);
    if ($ret === false) {
        //echo_msg(2,"$up_fl ファイルがありません。");
        return(2);
    }
    //echo_msg(2, "検証(update).....");
    rm_dir($tmpdir_rf);
    $ret = rf_update_unzip($tmpdir.$up_fl, $tmpdir, $pn, 0);
    fin_unlink($tmpdir.$up_fl);
    if ($ret !== true) {
        rm_dir($tmpdir_rf);
        //rf_error_log("up_fl:$up_fl");
        //rf_error_log("pn:'$pn'");
        //echo_msg(2,"$up_fl ファイルが異常です。");
        return(3);
    }
    $fl = $tmpdir_rf.$DS.$rfriends;
    if (!file_exists($fl)) {
        rm_dir($tmpdir_rf);
        //echo_msg(2,"$up_fl ファイルの内容が正しくありません。");
        return(4);
    }
    $update_dat2 = trim(file_get_contents($fl));
    //echo_msg(2,"$update_dat");
    //echo_msg(2,"$update_dat2");
    if (trim($update_dat) != $update_dat2) {
        rm_dir($tmpdir_rf);
        //echo_msg(2,"$up_fl ファイルのバージョンが一致しません。");
        return(5);
    }
    // ------------------------
    // アップデート中
    // ------------------------
    //rf_error_log('update exec');

    //echo_msg(2, "アップデート(update).....");
    $ret = rf_update_copy($rfproduct, $tmpdir, $rpath);
    if ($ret == 0) {
        //echo_msg(2,"アップデート(update)完了");
    } else {
        //echo_msg(2,"アップデート(update)異常終了");
        $ret = 1;
    }
    rm_dir($tmpdir_rf);

    //rf_error_log('update end');

    return($ret);
}
//  --------------------------------------------------------------------------
//  更新（SYS)
//  --------------------------------------------------------------------------
function rfmenu_sitecheck()
{
    global $tmpdir;
    global $rfriends;
    global $ui_mode;

    $ty = 0;
    $rf = $rfriends.".flg";

    $url = rf_get_down_url2();
    if ($url === false) {
        echo_msg(2, "サイトが不明です。");
        rf_pause();
        return false;
    }
    //echo_msg(2,$url);
    $updt = rf_update_dir();

    $ret = rf_update_get_sys($url.$updt,$rf, $tmpdir, $ty);
    if ($ret !== false) {
        return $url;
    }
/*
    $url = rf_get_down_url(1,$ty);
    if ($url === false) {
        echo_msg(2, "サイトが不明です。");
        rf_pause();
        return false;
    }
    //echo_msg(2,$url);
    $ret = rf_update_get_sys($url.$updt,$rf, $tmpdir, $ty);
    if ($ret !== false) {
        return $url;
    }
*/
    echo_msg(2,"サイトがダウンしているか、変更になっているようです。");
    echo_msg(2,"しばらくしてから、再度アクセスしてみてください。");
    echo_msg(2, "");

    if ($ui_mode == 2)  return false;

    $ans = echo_yesno(2, "中止しますか？(Y/n): ");
    if ($ans != "n" && $ans != "N") {
        return false;
    }
    echo_msg(2, "");
    $ans = echo_yesno(2, "新しいサイトを知っていますか？(y/N): ");
    if ($ans != "y" && $ans != "Y") {
        return false;
    }
    $url = echo_input(2, "新しいサイトのurlを入力してください : ");
    if ($url == "") {
        return false;
    }
    if (substr($url,-1) != "/") {
        $url .= "/";
    }
    $ret = rf_update_get_sys($url.$updt,$rf, $tmpdir, $ty);
    if ($ret !== false) {
        return $url;
    }
    echo_msg(2,"新しいサイトのurlが間違っています。");
    rf_pause();
    return false;
}
//  --------------------------------------------------------------------------
function rfmenu_update_db($url,$ty)
{
    global $rfriends;
    global $tmpdir;
    global $svcmode;

    $updb = array();
    // ------------------------
    // ヘッダファイルの読み込み
    // ------------------------

// 安定版
    $updb[0] = array(
      'upname' => "1.安定版　",
      'rf_fl'  => $rfriends."_0",
      'up_fl'  => "update_0.zip",
      'up_fln' => "update_0n.zip",
      'upflg'  => 0,
      'update_ver' => "",
      'update_dat' =>""
    );
// 開発版
    $updb[1] = array(
      'upname' => "2.開発版　",
      'rf_fl'  => $rfriends."_1",
      'up_fl'  => "update_1.zip",
      'up_fln' => "update_1n.zip",
      'upflg'  => 0,
      'update_ver' => "",
      'update_dat' =>""
    );
// 旧安定版
    $updb[2] = array(
      'upname' => "3.旧安定版",
      'rf_fl'  => $rfriends."_0x",
      'up_fl'  => "update_0x.zip",
      'up_fln' => "update_0xn.zip",
      'upflg'  => 0,
      'update_ver' => "",
      'update_dat' =>""
    );
// 旧開発版
    $updb[3] = array(
      'upname' => "4.旧開発版",
      'rf_fl'  => $rfriends."_1x",
      'up_fl'  => "update_1x.zip",
      'up_fln' => "update_1xn.zip",
      'upflg'  => 0,
      'update_ver' => "",
      'update_dat' =>""
    );
// ベータ版
if ($svcmode["service_mode"] == 1) {
  if ($svcmode["service_update_beta"] == 1) {
    $updb[4] = array(
      'upname' => "5.ベータ版",
      'rf_fl'  => $rfriends."_2",
      'up_fl'  => "update_2.zip",
      'up_fln' => "update_2n.zip",
      'upflg'  => 0,
      'update_ver' => "",
      'update_dat' =>""
    );
  }
}

    $imax = count_73($updb);

    for ($i=0; $i<$imax; $i++) {
        fin_unlink($tmpdir.$updb[$i]['up_fl']);
        fin_unlink($tmpdir.$updb[$i]['up_fln']);

        $ret = rf_update_get_sys($url,$updb[$i]['rf_fl'], $tmpdir, $ty);
        //echo_msg(2,$updb[$i]['rf_fl']." $tmpdir $ty");
        if ($ret === true) {
            $updb[$i]['upflg'] = 1;

            $rf_fl = $tmpdir.$updb[$i]['rf_fl'];
            $updb[$i]['update_dat'] = @file_get_contents($rf_fl);
            $v = explode(" ", trim($updb[$i]['update_dat']));
            $updb[$i]['update_ver'] = $v[3];

            $mt = @filemtime($rf_fl);
            $mtd = date("Y/m/d",$mt);
            $updb[$i]['upname'] .= " ($mtd)";
        } else {
            //echo_msg(2,$updb[$i]['rf_fl']." 取得エラー");
            $updb[$i]['upflg'] = 0;
            $updb[$i]['upname'] .= " (0000/00/00)";
        }
    }
    // ------------------------
    // メンテナンスモード
    // ------------------------
    if ($svcmode["service_mode"] == 1) {
        if ($svcmode["service_update_forbid"] == 1) {
            for ($i=0; $i<$imax; $i++) {
                $updb[$i]['upflg'] = 0;
            }
        }
    }
    // ------------------------
    // アップデートの確認
    // ------------------------
    for ($i=0; $i<$imax; $i++) {
        //$nam = rf_strimwidth($updb[$i]['upname']."        ",0,8);
        //$updb[$i]['upstr'] = sprintf("%-s : %s",$nam,$updb[$i]['update_ver']);
        $updb[$i]['upstr'] = $updb[$i]['upname']." : ".$updb[$i]['update_ver'];
        if ($updb[$i]['upflg'] == 1) {
            $updb[$i]['title'] = $updb[$i]['upstr']."";
            $updb[$i]['val'] = $i+1;
        } else {
            $updb[$i]['title'] = $updb[$i]['upstr']."(停止中)";
            $updb[$i]['val'] = 0;
        }
    }

    return $updb;
}
//  --------------------------------------------------------------------------
function rfmenu_update_sys_ret($ret)
{
    global $base;

    switch ($ret) {
        case 0:
            echo_msg(2, "アップデートに成功しました。");
            break;
        case 1:
            echo_msg(2, "アップデートに失敗しました。");
            break;
        case 2:
            echo_msg(2, "アップデートファイルがありません。");
            break;
        case 3:
            echo_msg(2, "アップデートファイルが異常です。");
            break;
        case 4:
            echo_msg(2, "アップデートファイルの内容が正しくありません。");
            break;
        case 5:
            echo_msg(2, "アップデートファイルのバージョンが一致しません。");
            break;
        case 8:
            echo_msg(2, "アップデートがありません。");
            break;
        case 9:
            echo_msg(2, "入力が間違っています。");
            break;
        case 10:
            echo_msg(2, "初期化が終了しました。");
            echo_msg(2, "");
            echo_msg(2, "一旦終了します。");
            return(1);
            break;
        case 11:
            echo_msg(2, "初期化が異常終了しました。");
            echo_msg(2, "");
            echo_msg(2, "一旦終了します。");
            return(1);
            break;
        case 99:
            return 0;
            break;
        default:
            break;
    }
    //rf_pause();
    return 0;
}
//  --------------------------------------------------------------------------
function rfmenu_update_sub($ty)
{
    global $usrdir;
    global $tmpdir;
    global $cfgdir;

    global $base;
    global $rfriends;
    global $rfproduct;
    global $DS;

    global $os_s;
    global $svcmode;
    global $ui_mode;
    global $ht_jump_addr;
    global $ht_jump_val2;
    global $ht_jump_confirm;
    // ----------------------------------
    $rfriends_ver = trim(file_get_contents($base.$rfriends));
    $ver = explode(" ", $rfriends_ver);
    $dmode = 0;
    $rpath = realpath($base."../");
    if (substr($rpath,-1) != $DS) {
        $rpath .= $DS;
    }
    //echo_msg(2, "rpath : $rpath '$DS'");
    //$o_tmpdir = $rpath.$rfproduct.$DS."tmp".$DS;
    // ------------------------------------------------------------------

    //echo_msg(2, "");
    echo_msg(2, "システム更新(SYS) Ver.1.20");
    // ----------------------------------
    // 空き領域チェック
    // ----------------------------------
    $fr = disk_free_space($base);
    //$rfr = rf_disk_fmt($fr,1);
    $fr = floor($fr / (1024*1024));
    echo_msg(2,"");
    echo_msg(2, "free space : $fr MB");
    if ($fr < 30) {
        echo_msg(2, "十分な空き容量がありません。");
        rf_pause(); 
        return 0;
    }
    $url = rfmenu_sitecheck();
    if ($url == false) {
        return 0;
    }
    $updt = rf_update_dir();
    $url0 = $url.$updt;
    $ht_jump_val2 = $url0;
    // ----------------------------------
    // zip extension
//
    $ret = phpzip();
    if ($ret == 1) {
        return($ret);
    }
    $tmpdir_rf = $tmpdir.$rfproduct;
    $ty = 0;

    $updb = rfmenu_update_db($url0,$ty);
    $upmax = count_73($updb);
    if ($upmax == 0) {
        return 0;
    }

    echo_scr(2, "");
    //echo_msg(2, "開発版にはバグの可能性あり。");
    //echo_msg(2, "異常発生時は安定版に戻してください。");
    echo_msg(2, "番組録音中のアップデートは失敗する可能性があります。");

    echo_scr(2, "");

    echo_msg(2, " OS  : $os_s");
    echo_msg(2, " 現在: $ver[3]");
    echo_msg(2, " site: $url0");

    if ($ui_mode == 2) {

        $ht_jump_confirm = "アップデートしますか？";
        echo_msg(2, "");
        $opt = array(
        "title"     => "アップデートを選択",
        "mode"       => 1,
        "multi"      => 0, /* 0 */
        "confirm"    => 1,
        "ht_selid"   => ""
        );
        ht_ask_list($updb,$opt);
        return 0;
    }
    echo_scr(2, "");
    for ($i=0;$i<$upmax;$i++) {
        if ($i == 2) echo_msg(2,"");
        echo_menu(2, $updb[$i]['title'],1);
    }

    echo_menu_ret_wt();

    echo_msg(2, "");
    $ans0 = echo_ask(2, "アップデートを選択(1-$upmax): ");
//------------------------------------------------
    if ($ans0 == "" || $ans0 == "R" || $ans0 == "r") {
         return 0;
    }
    echo_scr(2, "");

    $nox = rfmenu_check_range($ans0,1,$upmax);
    if ($nox === false) {
        return 0;
    }
    $i = $nox - 1;
    $upflg = $updb[$i]['upflg'];
    if ($upflg != 1) {
        $ret0 = rfmenu_update_sys_ret(8);
        rf_pause();
        return $ret0;
    }
    $ftpass = "";
    $up_fl = $updb[$i]['up_fl'];
    $update_dat = $updb[$i]['update_dat'];

    if ($svcmode["service_mode"] == 1 && $svcmode["service_update_beta"] == 1) {
        $ftpass = $svcmode["service_update_beta_mgc"]; 
    }

    if ($ftpass != "") {
        $up_fl = $updb[$i]['up_fln'];
    }

    $a0 = echo_yesno(2, "実行しますか? (y/N) : ");
    if (($a0 != "y") && ($a0 != "Y")) {
        return 0;
    }
//------------------------------------------------
    echo_msg(2,$rpath);
    $ret = rf_update_script($url0, $update_dat, $up_fl, $rpath, $ftpass, $ty);
    $ret0 = rfmenu_update_sys_ret($ret);
    if ($ret == 0) {
        fin_unlink($base."skipfile");
        $mes = rfmenu_update_para_all_auto();
        
        //foreach($mes as $m) {
        //    echo_msg(2,$m);
        //}
        //rf_update_fin_sys();
    }
    rf_pause();
    return $ret0;
}
//  --------------------------------------------------------------------------
function rf_update_inifile($mode,$fl_sys,$fl_usr,$ini_sys,$ini_usr)
{
global $cfgdir;

$ini_dat = array_merge($ini_sys, $ini_usr);

if ($mode == 1) {
    $ini_dat["ini_version"] = $ini_sys["ini_version"];
}
if ($mode == 2) {
    $ini_dat["tag_ini_version"] = $ini_sys["tag_ini_version"];
}

$lines = file($fl_sys);
$lines2 = array();
foreach($lines as $line) {
	$parts = parse_ini_string($line);
	if (empty($parts)) {
		$lines2 [] = $line;
	} else {
		$keys = array_keys($parts);
		$key = $keys[0];
		$val = $ini_dat[$key];
		if (!is_numeric($val)) {
			$val = '"'.$val.'"';
		}
		$lines2[] = $key . " = " . $val. "\n";
	}
}
//
//  古いキーは捨てる(2023/03/10)
/*
$n = 0;
$old_key = array();

foreach ($ini_usr as $key => $val) {
    if (array_key_exists($key, $ini_sys)) continue;
    //echo_msg(2,"key : $key");

    $old_key[$key] = $val;
    $n++;
}

if ($n > 0) {
    $lines2[] = ";".str_repeat("-",40)."\n";
    $lines2[] = "; 以下のキーは古いキーです。($n)\n";
    $lines2[] = "; \n";
    $lines2[] = ";[oldkey]\n";

    foreach ($old_key as $key => $val) {
        $lines2[] = ";".$key . " = " . $val. "\n";
    }   
    $lines2[] = ";".str_repeat("-",40)."\n";
}
*/

$ret = file_put_contents($fl_usr.".new",$lines2);
if ($ret === false ) return false;
$ret = rf_copy($fl_usr,$fl_usr.".bak");
if ($ret === false ) return false;
$ret = rf_move($fl_usr.".new",$fl_usr);
if ($ret === false ) {
    $ret = rf_copy($fl_usr.".bak",$fl_usr);
    return false;
}
return true;
}
//  --------------------------------------------------------------------------
function rf_update_inifile_simple($fl,$dat)
{

$lines = file($fl);
$lines2 = array();
foreach($lines as $line) {
	$parts = parse_ini_string($line);
	if (empty($parts)) {
		$lines2 [] = $line;
	} else {
		$keys = array_keys($parts);
		$key = $keys[0];
        if (array_key_exists($key,$dat)) {
            $val = $dat[$key];
        } else {
            $val = $keys[1];
        }
		if (!is_numeric($val)) {
			$val = '"'.$val.'"';
		}
		$lines2[] = $key . " = " . $val. "\n";
	}
}

$ret = file_put_contents($fl.".new",$lines2);
if ($ret === false ) return false;
$ret = rf_copy($fl,$fl.".bak");
if ($ret === false ) return false;
$ret = rf_move($fl.".new",$fl);
if ($ret === false ) {
    $ret = rf_copy($fl.".bak",$fl);
    return false;
}
return true;
}
//  --------------------------------------------------------------------------
function rfmenu_update_para($mode,$file)
{
    global $scrdir;
    global $defdir;
    global $cfgdir;
    global $DS;

    //global $rfriendsini;
    //global $rfriendsforceini;

    global $ui_mode;

    $fl_sys = $scrdir.$file;
    $fl_usr = $cfgdir.$file;
    $fl_dif = $cfgdir.$file.".dif";

    //echo_msg(2, "sys : $fl_sys");
    //echo_msg(2, "usr : $fl_usr");

    if (($ini_sys = @parse_ini_file($fl_sys)) === false) {
        if ($ui_mode == 2) return false;
        echo_msg(2, "$fl_sys parse error");
        echo_msg(2, "システム設定に誤りがあります。");
        return false;
    }
    if (($ini_usr = @parse_ini_file($fl_usr)) === false) {
        if ($ui_mode == 2) return false;
        echo_msg(2, "$fl_usr parse error");
        echo_msg(2, "ユーザ設定に誤りがあります。");
        echo_msg(2, "該当ファイルを修正または削除してください。");
        return false;
    }
/*
    rf_error_log("$file");
    if ($file == $rfriendsini) {
      $fl_force = $scrdir.$rfriendsforceini;
      if (($ini_force = @parse_ini_file($fl_force)) === false) {
          if ($ui_mode == 2) return false;
          echo_msg(2, "$fl_force parse error");
          echo_msg(2, "強制設定に誤りがあります。");
          echo_msg(2, "該当ファイルを修正または削除してください。");
          return false;
      }
      $ini_usr = del_iniusr($ini_usr,$ini_force);
    }
*/
    $ret = rf_update_inifile($mode,$fl_sys,$fl_usr,$ini_sys,$ini_usr);
    return $ret;
}
//  --------------------------------------------------------------------------
function rfmenu_update_para_all()
{
    global $defkwdir;
    global $kwdir;
    global $program_kw;
 
    $lists = [
             [1,"rfriends.ini",    "パラメータ"],
             [2,"rfriends_tag.ini","タグ"      ],
             [3,"usrdir.ini",      "ユーザdir" ],
             [4,"premium.ini",     "プレミアム"],
             [5,"sendmail.ini",    "メール"    ],
             [6,"rfplay.ini",      "パラメータ"]
             ];
    echo_scr(2,"");
    echo_scr(2, "設定ファイルを最新にします。");
    echo_scr(2, "ただし、現在のユーザ設定値は保持します。");
    echo_scr(2, "");
    foreach($lists as $list) {
        $no   = $list[0];
        $file = $list[1];
        $name = rf_strimwidth($list[2] . str_repeat(" ",12),0,12);
        //$txt = sprintf("%2d %s(%s)",$no,$name,$file);
        $txt = sprintf("・ %s(%s)",$name,$file);
        echo_scr(2,$txt);
    }
    echo_scr(2, "");

    $ans = echo_yesno(2, "実行しますか? (y/N): ");
    if ($ans == "y" || $ans == "Y") {
      echo_scr(2, "");
      foreach($lists as $list) {
        $no   = $list[0];
        $file = $list[1];
        $name = rf_strimwidth($list[2] . str_repeat(" ",12),0,12);
        //$txt = sprintf("%2d %s(%s)",$no,$name,$file);
        $txt = sprintf("・ %s(%s)",$name,$file);
        echo_scr(2,$txt);
        $ret = rfmenu_update_para($no,$file);
        //echo_scr(2,"");
        if ($ret === false) {
            echo_scr(2,"　　更新に失敗しました。");
        } else{
            echo_scr(2,"　　更新しました。");
        }
      }
    }

    $defpgm = $defkwdir.$program_kw;
    $pgm = $kwdir.$program_kw;

    $ft_defpgm = filemtime($defpgm);
    $ft_pgm = filemtime($pgm);

    if ($ft_defpgm > $ft_pgm) {
      echo_scr(2, "");
      echo_scr(2, "重複番組設定の更新データがあります。");
      echo_scr(2, "現在のデータ : ".date ("Y/m/d H:i:s", $ft_pgm));
      echo_scr(2, "更新データ   : ".date ("Y/m/d H:i:s", $ft_defpgm));
      echo_scr(2, "");
      $ans = echo_yesno(2, "更新しますか? (y/N): ");
      if ($ans == "y" || $ans == "Y") {
          echo_scr(2, "");
          $ret = rf_move($pgm,$pgm.".bak");
          if ($ret === false) {
            echo_scr(2,"　　更新に失敗しました。");
          } else{
            echo_scr(2,"　　更新しました。");
          }
      }
    }
}
//  --------------------------------------------------------------------------
function rfmenu_update_para_all_auto()
{
    global $defkwdir;
    global $kwdir;
    global $program_kw;
 
    $lists = [
             [1,"rfriends.ini",    "パラメータ"],
             [2,"rfriends_tag.ini","タグ"      ],
             [3,"usrdir.ini",      "ユーザdir" ],
             [4,"premium.ini",     "プレミアム"],
             [5,"sendmail.ini",    "メール"    ],
             [6,"rfplay.ini",      "パラメータ"]
             ];
    echo_scr(2,"");
    echo_scr(2, "設定ファイルを最新にします。");
    echo_scr(2, "ただし、現在のユーザ設定値は保持します。");
    echo_scr(2, "");

    foreach($lists as $list) {
        $no   = $list[0];
        $file = $list[1];
        $name = rf_strimwidth($list[2] . str_repeat(" ",12),0,12);
        $txt = sprintf("%s(%s)",$name,$file);
        $ret = rfmenu_update_para($no,$file);
        if ($ret === false) {
            echo_scr(2,"・失敗 : ".$txt);
        } else{
            echo_scr(2,"・成功 : ".$txt);
        }
    }

    $defpgm = $defkwdir.$program_kw;
    $pgm = $kwdir.$program_kw;

    $ft_defpgm = filemtime($defpgm);
    $ft_pgm = filemtime($pgm);

    if ($ft_defpgm > $ft_pgm) {
      echo_scr(2, "");
      echo_scr(2, "重複番組設定の更新データがあります。");
      echo_scr(2, "現在のデータ : ".date ("Y/m/d H:i:s", $ft_pgm));
      echo_scr(2, "更新データ   : ".date ("Y/m/d H:i:s", $ft_defpgm));
      echo_scr(2, "");
      $ret = rf_move($pgm,$pgm.".bak");
      if ($ret === false) {
            echo_scr(2,"更新に失敗しました。");
      } else{
            echo_scr(2,"更新しました。");
      }
    }
}
//  --------------------------------------------------------------------------
