<?php
//------------------------------------------------------------
// Rfriends (radiko radiru録音ツール)
// 2017.04.22 by mapi
// common update
// ---------------------------------------------
// php zip
// ---------------------------------------------
function phpzip()
{
    $flg =0;
    $mo = get_loaded_extensions();
    foreach ($mo as $v) {
        //9echo_msg(2,"$v");
        if ($v == "zip") {
            break;
        }
    }
    if ($v != "zip") {
        $flg =1;
    }
    // ----------------------------------
    if ($flg == 1) {
        echo_msg(2, "ツール(zip)を更新します.....");
        rfmenu_update_sys();
        echo_msg(2, "更新完了");
        echo_msg(2, "");
        echo_msg(2, "一旦終了します。");
    }
    return ($flg);
}
// ---------------------------------------------
// rfriends unzip
// ---------------------------------------------
function rf_update_unzip($fl, $dir, $pn, $flg)
{
    global $DS;
    global $cmd_which;

    if ($flg == 1) {
        $dst = $dir."_test".$DS;
    } else {
        $dst = $dir;
    }
    $ret = rf_extract($fl,$dst,$pn);
    if ($ret === true) return $ret;
    if ($pn == "") return $ret;

    $ret = exec("$cmd_which 7z");
    if ($ret === false) return $ret;

    $ret = rfgw_extract_7z($fl, $dir, $pn);
    return $ret;
}
// ---------------------------------------------
// rfriends update
// ---------------------------------------------
function rf_get_down_url($no,$ty)
{
    global $scrdir;
    global $DS;
/*
    $str = file_get_contents($scrdir."update");

    $up = "update";
    // Develop
    if ($ty == 1) {
        $up     = "secret";
    }

    $upurl = base64_decode($str);

    $src = $upurl.$up."/";
*/
    //$str = file_get_contents($scrdir."update");
    $str = file($scrdir."update");
    if ($str === false) {
        return false;
    }
    $n = count_73($str) - 1;
    if (($no < 0) || ($no > $n)) {
        $url = $str[0];
    } else {
        $url = $str[$no];
    }

    $url = trim($url);
    if (substr($url,-1) != "/") {
       $url .= "/";
    }
    return($url);
}
// ---------------------------------------------
function rf_get_down_url2()
{
    global $scrdir;
    global $DS;
    global $rfriends;

    $str = file($scrdir."update");
    if ($str === false) {
        return false;
    }
    $n = count_73($str);
    if ($n <= 0) {
        return false;
    }

    $updt = rf_update_dir();
    foreach($str as $s) {
        $url = trim($s);
        if (strlen($url) < 8) continue;
        if (substr($url,0,1) == ";") continue;
        if (substr($url,-1) != "/") {
           $url .= "/";
        }
        $flf = $url.$updt.$rfriends.".flg";
        if (rf_wget_spider2($flf,1,1) !== false) return $url;
        rf_error_log("rf_get_down_url2:$url not found");
    }

    return false;
}
// ---------------------------------------------
// updtdir
// ---------------------------------------------
function rf_update_dir()
{
    global $rfproduct;

    $updt = "update3/";
    if ($rfproduct == "rfriends2") $updt = "update/";
    return $updt;
}
// ---------------------------------------------
// remove dir all
// ---------------------------------------------
function rm_dir($dr)
{
    if (!is_dir($dr)) {
        return;
    }
    foreach (glob($dr . '/*') as $fl) {
        if (is_dir($fl)) {
            rm_dir($fl);
        } else {
            unlink($fl);
        }
        //echo ($fl."\n");
    }
    rmdir($dr);
}
//------------------------------------------------------------
