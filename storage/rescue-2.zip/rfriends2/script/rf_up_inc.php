<?php
//------------------------------------------------------------
//
// rfriends 更新
//
// 2021/04/13 by mapi
//
//------------------------------------------------------------
function rf_wget($url, $out, $opt)
{
    global $wget_opt;

    fin_unlink($out);
    //echo_msg(2,"$url $out");
    $exec_cmd = "wget $wget_opt $opt $url -O $out";
    $ret = external_program($exec_cmd);
    if ($ret != 0) {
        fin_unlink($out);
        return false;
    }
    if (!file_exists($out)) {
        return false;
    }
    if (filesize($out) == 0) {
        fin_unlink($out);
        return false;
    }
    return true;
}
//------------------------------------------------------------
function external_program($exec_cmd)
{
    global $bindir;

    $cmd = $bindir.$exec_cmd;
    system($cmd, $ret);
    return $ret;
}
//------------------------------------------------------------
function count_73($ar)
{
    if (!empty($ar)) {
        return count($ar);
    } else {
        return 0;
    }
}
//  --------------------------------------------------------------------------
function rf_extract($ef_b,$dstdir,$pn)
{
$zip = new ZipArchive;
if ($zip->open($ef_b) !== true) {
    //echo_msg(2,"open error");
    return false;
}
if ($pn != "") {
    if ($zip->setPassword($pn) !== true) {
        $zip->close();
        //echo_msg(2,"pn error");
        return false;
    }
}

if ($zip->extractTo($dstdir) != true) {
    $zip->close();
    //echo_msg(2,"extract error");
    return false;
}
$zip->close();
return true;
}
// ---------------------------------------------
function rfmenu_check_digit($ans)
{
    $no = explode(",", trim($ans));
    if (count_73($no) <= 0) {
        return false;
    }

    foreach ($no as $val) {
        $ret = ctype_digit($val);
        if ($ret == false) {
            return false;
        }
    }
    return $no;
}
// ---------------------------------------------
function rfmenu_check_range($ans,$min,$max)
{
    $no = explode(",", trim($ans));
    if (count_73($no) != 1) {
        return false;
    }

    $ans = $no[0];
    $ret = ctype_digit($ans);
    if ($ret == false) {
            return false;
    }
    if ($ans < $min || $ans > $max) {
        return false;
    }
    return $ans;
}
//----------------------------------------------
function read_stdin()
{
    global $scrdir;

    //$ans = trim(fgets(STDIN,128));
    $ans = trim(fgets(STDIN));
    return $ans;
}

// ---------------------------------------------
function fin_unlink($src)
{
    if (file_exists($src)) {
        $ret = unlink($src);
    }
}
//------------------------------------------------------------
function echo_msg($m_level, $msg)
{
    echo "$msg".PHP_EOL;
}
//------------------------------------------------------------
function echo_scr($m_level, $msg)
{
    echo "$msg".PHP_EOL;
}
//------------------------------------------------------------
function echo_ask($m_level, $msg)
{
    echo "$msg";
    $ans = read_stdin();
    echo_scr(2, "");
    return $ans;
}
//------------------------------------------------------------
function echo_yesno($m_level, $msg)
{
    echo "$msg";
    $ans = read_stdin();
    echo_scr(2, "");
    return $ans;
}
//------------------------------------------------------------
function echo_menu($m_level, $msg,$nl)
{
    $newline = PHP_EOL;
    if ($nl == 0 ) {
        $newline = "";
    }
    echo $msg.$newline;
}
//------------------------------------------------------------
function echo_menu_all_wt()
{
//
}
//------------------------------------------------------------
function echo_menu_ret_wt()
{
//
}
//------------------------------------------------------------
function echo_menu_wt($msg)
{
//
}
//------------------------------------------------------------
function rf_pause()
{
    //$ans = read_stdin();
    return;
}
// ---------------------------------------------
//
// rfriends OS gateway 機種別
// This file should be placed on top
// 2019/11/17 by mapi
//
// ---------------------------------------------
function get_rfriends_exeos()
{
    global $rfriends_exeos;

    switch ($rfriends_exeos) {
        case "WIN":
        case "OSX":
        case "LNX":
            return $rfriends_exeos;
        break;
        default:
            echo "--- rfriends_exeos is not defined.\n";
            exit(1);
        break;
    }
}
//------------------------------------------------------------
function set_rfriends_exeos()
{
global $rfriends_exeos;
global $cmd_which;

$os = PHP_OS;
switch ($os) {
    case "WINNT":
    case "WIN32":
        $rfriends_exeos = "WIN";
        $cmd_which = "";
        break;
    case "Darwin":
        $rfriends_exeos = "OSX";
        $cmd_which = "command -v";
        break;
    case "Linux":
        $rfriends_exeos = "LNX";
        $cmd_which = "command -v";
        break;
    default:
        echo "--- This is unknown OS ($os).\n";
        $rfriends_exeos = "LNX";
        $cmd_which = "command -v";
        //exit (1);
        break;
}
}
//------------------------------------------------------------
function set_rfriends_dir()
{
global $bindir;
global $phpdir;
global $null_out;
global $DS;
global $base;

$exeos = get_rfriends_exeos();

switch ($exeos) {
    case "WIN":
        $bindir = $base."bin".$DS;
        $phpdir = $bindir."php".$DS;
        $null_out = "nul";
        break;
    case "OSX":
        $bindir = "/usr/local/bin/";
        $phpdir = "/usr/local/bin/";
        $null_out = "/dev/null";

        exec("brew --prefix",$out1,$ret1);
        if ($ret1 == 0 ) {
            $bindir = $out1[0]."/bin/";
            $phpdir = $bindir;
        }
        break;
    case "LNX":
        $bindir = "";
        $phpdir = "";
        $null_out = "/dev/null";
        break;
    default:
        echo "--- rfriends_exeos is not defined.\n";
        exit(1);
        break;
}
}
// ---------------------------------------------
// rfriends get
// ---------------------------------------------
function rf_update_get_sys($url,$fl, $dir, $ty)
{
    global $rfriends;

    $src = $url.$fl;
    $dst = $dir.$fl;
    // ----------------------------------
    fin_unlink($dst);

    $exeos = get_rfriends_exeos();

    switch ($exeos) {
        case "WIN":
            //$src = $src."w";
            $ret = rf_wget($src, $dst, "");
            break;
        case "OSX":
        case "LNX":
            //$src = $src."l";
            $ret = rf_wget($src, $dst, "");
            break;
        default:
            echo "--- rfriends_exeos is not defined.\n";
            exit(1);
        break;
    }
    //echo_msg(2,$exec_cmd);
    return ($ret);
}
// ---------------------------------------------
// rfriends copy
// ---------------------------------------------
function rf_update_copy($dir, $src, $dst)
{
    global $DS;
    global $base;
    global $base0;

    $ipath = realpath($base."../");
    if (substr($ipath,-1) != $DS) {
        $ipath .= $DS;
    }
    //echo_msg(2, "ipath : $ipath");

    $ipath_name = str_replace($ipath,"",$base0);
    $sd = $src.$dir;
    $dd = $dst.$ipath_name;
    echo_msg(2,"sdir : $sd");
    echo_msg(2,"ddir : $dd");

    $exeos = get_rfriends_exeos();

    switch ($exeos) {
        case "WIN":
            $exec_cmd = "xcopy /E /R /Y /I $sd $dd > nul ";
            //$exec_cmd = "xcopy /E /R /Y /I $src $dst ";
            //$exec_cmd = "robocopy /E /R:0 /MOVE $src $dst ";
            break;
        case "OSX":
        case "LNX":
            $exec_cmd = "cp -a $sd/* $dd > /dev/null ";
            break;
        default:
            echo "--- rfriends_exeos is not defined.\n";
            exit(1);
        break;
    }
    system($exec_cmd, $ret);
    //echo_msg(2,"$exec_cmd ret = $ret");
    return($ret);
}
//------------------------------------------------------------
function rf_wget_spider2($url,$tout,$try)
{
    $opt = "--spider -q -T $tout -t $try";
    $exec_cmd = "wget $opt $url";
    $ret = external_program($exec_cmd);
    if ($ret != 0) {
        return false;
    }
    return true;
}
//------------------------------------------------------------
function rf_strimwidth($str,$st,$width)
{
global $ui_mode;

    if ($ui_mode == 2) return $str;

    $ret = mb_strimwidth($str,$st,$width,'','utf-8');
    return $ret;
}
//------------------------------------------------------------
function rf_copy($inf,$otf)
{
   $mt = filemtime($inf);
   $ret = @copy($inf,$otf);
   if ($ret === true) {
       rf_touch_tm($otf,$mt);
   }
   return $ret;
}
//------------------------------------------------------------
function rf_move($inf,$otf)
{
    //echo_prn(1,     "move");
    //echo_prn(1,     "  from : $inf");
    //echo_prn(1,     "  to   : $otf");
    $ret = rf_copy($inf,$otf);
    if ($ret === false) {
        return false;
    }
    $ret = unlink($inf);
    if ($ret === false) {
        return false;
    }
    return true;
}
//------------------------------------------------------------
function rf_touch_tm($fl,$tm)
{
    $ret = @touch($fl,$tm);
    return $ret;
}
//-------------------------------------------------------------
$DS = DIRECTORY_SEPARATOR;
$curdir = dirname(__FILE__).$DS;
$base0 = realpath($curdir."../");
$base = $base0.$DS;

require_once("rf_product.php");
// ---------------------------------------------
$os_s = PHP_OS;
$svcmode["service_mode"] = 0;

$tmpdir = $base."tmp".$DS;
$scrdir = $base."script".$DS;
$cfgdir = $base."config".$DS;

$radiko_host = "radiko.jp";
$msg_level = 2;
$upty = 0;
$wget_opt = "--inet4-only -q -t 5";
//------------------------------------------------------------
// timezone & OS
//------------------------------------------------------------
date_default_timezone_set('Asia/Tokyo');
$dt = date_default_timezone_get();
if ($dt != 'Asia/Tokyo') {
    echo "--- timezone error $dt\n";
    exit(1);
}
//------------------------------------------------------------
set_rfriends_exeos();
set_rfriends_dir();
//------------------------------------------------------------
