<?php
 function ht_sub_bsd() { echo_msg(2,""); echo_msg(2,"freebsd : この機能は現在開発中です。"); } function ht_sub_bsd_s($val) { echo_msg(2,"freebsd : $val"); } function ht_sub_bsd_ss($val,$val2) { echo_msg(2,"freebsd : $val $val2"); } ?>
