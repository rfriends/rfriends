<?php
 function ht_sub_osx() { echo_msg(2,""); echo_msg(2,"macOS : この機能は現在開発中です。"); } function ht_sub_osx_s($val) { echo_msg(2,"macos : $val"); } function ht_sub_osx_ss($val,$val2) { echo_msg(2,"macos : $val $val2"); } ?>
