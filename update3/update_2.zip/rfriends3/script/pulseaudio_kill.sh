#!/bin/sh
# Rfriends (radiko radiru録音ツール)
cd `dirname $0`
base=`cd ../;pwd`/
export XDG_RUNTIME_DIR=/run/user/$(id -u)
# ------------------------------------ exec
env
pulseaudio --kill
#ps -e | grep pulseaudio
# ------------------------------------ 
