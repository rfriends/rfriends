#!/bin/sh
# 
# -----------------------------------------
# rfriends3 rescue インストーラー
#
# 2025/02/13 by mapi
# -----------------------------------------
#
echo rescue版rfriendsインストーラー for windows Ver. 1.00
echo
echo rescue版rfriendsをダウンロードし解凍します。
echo ウェブサーバを起動中の場合は、必ず終了させてください。
echo
PDIR=`basename ${PWD}`
echo $PDIR

if [ $PDIR = rfriends3 ]; then
    echo rfriends3用レスキューを行います。
    file=rescue.zip
elif [ $PDIR = rfriends2 ]; then
    echo rfriends2用レスキューを行います。
    file=rescue-2.zip
else
    echo ディレクトリ異常です。
    echo 終了します。
    exit 1
fi
echo
read -p "処理を開始しますか　(y/n) ? " yn
if [ "$yn" != "y" ]; then
    echo "終了します"
    exit 1;
fi
# -----------------------------------------
# 開始
#

url=https://raw.githubusercontent.com/rfriends/rfriends/main/storage/$file

cd ..
rm -f $file 
# -----------------------------------------
# ファイルダウンロード
#
wget $url -O $file

echo
echo downloaded
# -----------------------------------------
# ファイルの展開
#
unzip -o $file
echo unzipped
rm -f $file
echo finished
echo
# -----------------------------------------
# 終了
#
exit 0
