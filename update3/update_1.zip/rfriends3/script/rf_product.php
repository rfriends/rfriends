<?php
 $p = $base."_Rfriends2"; if (file_exists($p)) { $rfriends = "_Rfriends2"; $rfproduct = "rfriends2"; } else { $rfriends = "_Rfriends3"; $rfproduct = "rfriends3"; } 