#!/bin/sh
# Rfriends (radiko radiru録音ツール)
cd `dirname $0`
base=`cd ../;pwd`/

ex=rfriends_exec

if [ $# -eq 1 ]; then
  exno=$1
  opt=
  phpdir=
elif [ $# -eq 2 ]; then
  exno=$1
  opt=$2
  phpdir=
elif [ $# -eq 3 ]; then
  exno=$1
  opt=$2
  phpdir=$3
else
  exno=
  opt=
  phpdir=
fi
# ------------------------------------ exec
${phpdir}php ${base}script/$ex.php $exno $opt
# ------------------------------------ 
