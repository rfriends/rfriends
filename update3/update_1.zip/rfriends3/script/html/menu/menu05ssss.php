<?php
 $ex_type = $ex_radiru_vod; ht_subtitle($subno,""); switch ($subno) { case "0501": ht_play_abort_server("聴取"); break; default: ht_development($subno,$val,2); break; } 