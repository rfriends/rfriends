#!/bin/sh
# 録音ツール
cd `dirname $0`
base=`pwd`/

ex=rescue
php ${base}script/$ex.php

echo done
